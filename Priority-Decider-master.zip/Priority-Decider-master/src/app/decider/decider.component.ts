import { Component, OnInit } from '@angular/core';
import {
  FormControl,
  FormBuilder,
  FormGroup,
  Validators,
  FormsModule,
  NgForm
} from "@angular/forms";

@Component({
  selector: 'app-decider',
  templateUrl: './decider.component.html',
  styleUrls: ['./decider.component.scss']
})
export class DeciderComponent implements OnInit {

  constructor( private formBuilder: FormBuilder) { 
   
  }
  detailsForm: FormGroup;
  pandemicList: any = [
    {value: 'COVID19', viewValue: 'COVID19'},
    {value: 'PANDEMIC1', viewValue: 'PANDEMIC1'},
    {value: 'PANDEMIC2', viewValue: 'PANDEMIC2'}  
  ];
  showAsy:Boolean = false;
  symptomatic:Boolean = false;

  ngOnInit() {
   this.detailsForm = this.formBuilder.group({
    pid : new String(),
    pandemic : new String(),
    symptomatic: false
    });
  }
  onSelect(pandemic: String){
    console.log("here ", pandemic);
     if(pandemic == "COVID19"){
      this.showAsy = true;
      this.symptomatic = false;
     }else {
      this.showAsy = false;
      this.symptomatic = false;
     }
  }
  puid:String;
  getInfo(decForm){
    console.log(decForm);
    this.puid = decForm.pid
    if(decForm.symptomatic == null){
      this.symptomatic = false;
    }else{
    this.symptomatic = decForm.symptomatic;
    }
    this.detailsForm.disable();
  }
  restForm(){
    console.log("in reset");
    this.detailsForm.enable();
    this.puid = undefined;
    this.symptomatic = false
    this.detailsForm.reset();
  }

}
